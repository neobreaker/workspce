contrib_world -- opencv_contrib container
=========================================

contrib_world is the module that when built, contains all other opencv_contrib modules.
It may be used for the more convenient redistribution of opencv binaries.
